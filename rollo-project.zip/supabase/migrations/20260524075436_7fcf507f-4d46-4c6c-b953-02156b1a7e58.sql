
-- Enums
CREATE TYPE public.account_type AS ENUM ('rider', 'driver');
CREATE TYPE public.vehicle_type AS ENUM ('Sedan', 'SUV / XL', 'XL Van', 'Luxury');
CREATE TYPE public.booking_status AS ENUM ('pending', 'matched', 'arriving', 'on_trip', 'complete', 'cancelled');

-- Profiles (no FK to auth.users so we can seed demo drivers)
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL DEFAULT 'New Rider',
  account_type public.account_type NOT NULL DEFAULT 'rider',
  avatar_initials TEXT NOT NULL DEFAULT 'NR',
  rating NUMERIC(3,2) NOT NULL DEFAULT 5.00,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "profiles readable by signed-in users"
  ON public.profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "users update own profile"
  ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id);
CREATE POLICY "users insert own profile"
  ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

-- Driver profiles
CREATE TABLE public.driver_profiles (
  user_id UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  vehicle public.vehicle_type NOT NULL DEFAULT 'Sedan',
  tags TEXT[] NOT NULL DEFAULT '{}',
  base_fare NUMERIC(6,2) NOT NULL DEFAULT 2.50,
  per_mile NUMERIC(6,2) NOT NULL DEFAULT 1.60,
  per_min NUMERIC(6,2) NOT NULL DEFAULT 0.32,
  eta_min INTEGER NOT NULL DEFAULT 5,
  is_online BOOLEAN NOT NULL DEFAULT false,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.driver_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "driver profiles readable by signed-in users"
  ON public.driver_profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "driver updates own driver profile"
  ON public.driver_profiles FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Bookings
CREATE TABLE public.bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rider_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  driver_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  pickup TEXT NOT NULL DEFAULT 'Current location',
  dropoff TEXT NOT NULL DEFAULT 'Destination',
  status public.booking_status NOT NULL DEFAULT 'pending',
  price NUMERIC(7,2) NOT NULL,
  miles NUMERIC(5,2) NOT NULL DEFAULT 5,
  mins INTEGER NOT NULL DEFAULT 12,
  rating INTEGER,
  savings_vs_uber NUMERIC(6,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "bookings visible to rider or driver"
  ON public.bookings FOR SELECT TO authenticated
  USING (auth.uid() = rider_id OR auth.uid() = driver_id);
CREATE POLICY "rider creates own bookings"
  ON public.bookings FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = rider_id);
CREATE POLICY "rider or driver updates booking"
  ON public.bookings FOR UPDATE TO authenticated
  USING (auth.uid() = rider_id OR auth.uid() = driver_id);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_name TEXT;
  v_type public.account_type;
  v_initials TEXT;
BEGIN
  v_name := COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1));
  v_type := COALESCE((NEW.raw_user_meta_data->>'account_type')::public.account_type, 'rider');
  v_initials := upper(substr(v_name, 1, 2));

  INSERT INTO public.profiles (id, full_name, account_type, avatar_initials)
  VALUES (NEW.id, v_name, v_type, v_initials);

  IF v_type = 'driver' THEN
    INSERT INTO public.driver_profiles (user_id) VALUES (NEW.id);
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Seed 6 demo drivers
WITH new_drivers AS (
  INSERT INTO public.profiles (full_name, account_type, avatar_initials, rating) VALUES
    ('Maya R.',  'driver', 'MR', 4.90),
    ('Jamal T.', 'driver', 'JT', 4.80),
    ('Sofia L.', 'driver', 'SL', 4.70),
    ('Derek M.', 'driver', 'DM', 4.95),
    ('Aisha K.', 'driver', 'AK', 4.60),
    ('Luis P.',  'driver', 'LP', 4.50)
  RETURNING id, full_name
)
INSERT INTO public.driver_profiles (user_id, vehicle, tags, base_fare, per_mile, per_min, eta_min, is_online)
SELECT id,
  CASE full_name
    WHEN 'Maya R.'  THEN 'Sedan'::public.vehicle_type
    WHEN 'Jamal T.' THEN 'SUV / XL'::public.vehicle_type
    WHEN 'Sofia L.' THEN 'Sedan'::public.vehicle_type
    WHEN 'Derek M.' THEN 'SUV / XL'::public.vehicle_type
    WHEN 'Aisha K.' THEN 'Sedan'::public.vehicle_type
    WHEN 'Luis P.'  THEN 'XL Van'::public.vehicle_type
  END,
  CASE full_name
    WHEN 'Maya R.'  THEN ARRAY['Top rated','Female driver']
    WHEN 'Jamal T.' THEN ARRAY['Pet-friendly']
    WHEN 'Sofia L.' THEN ARRAY['Female driver']
    WHEN 'Derek M.' THEN ARRAY['Top rated']
    WHEN 'Aisha K.' THEN ARRAY['Pet-friendly','Female driver']
    WHEN 'Luis P.'  THEN ARRAY[]::TEXT[]
  END,
  2.50,
  CASE full_name WHEN 'Maya R.' THEN 1.55 WHEN 'Jamal T.' THEN 1.80 WHEN 'Sofia L.' THEN 1.50 WHEN 'Derek M.' THEN 1.85 WHEN 'Aisha K.' THEN 1.60 WHEN 'Luis P.' THEN 2.10 END,
  CASE full_name WHEN 'Maya R.' THEN 0.30 WHEN 'Jamal T.' THEN 0.35 WHEN 'Sofia L.' THEN 0.28 WHEN 'Derek M.' THEN 0.36 WHEN 'Aisha K.' THEN 0.31 WHEN 'Luis P.' THEN 0.40 END,
  CASE full_name WHEN 'Maya R.' THEN 3 WHEN 'Jamal T.' THEN 5 WHEN 'Sofia L.' THEN 6 WHEN 'Derek M.' THEN 4 WHEN 'Aisha K.' THEN 8 WHEN 'Luis P.' THEN 9 END,
  true
FROM new_drivers;
