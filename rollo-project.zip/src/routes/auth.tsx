import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/useAuth";

export const Route = createFileRoute("/auth")({
  head: () => ({ meta: [{ title: "rollo — sign in" }] }),
  component: AuthPage,
});

function AuthPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [accountType, setAccountType] = useState<"rider" | "driver">("rider");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && user) navigate({ to: "/" });
  }, [user, loading, navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setBusy(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/`,
            data: { full_name: fullName || email.split("@")[0], account_type: accountType },
          },
        });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (e: unknown) {
      setErr(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="inline-block px-3 py-1.5 rounded-full bg-card shadow-sm">
            <span className="text-primary text-xl font-medium tracking-tight">rollo</span>
          </div>
          <h1 className="mt-4 text-2xl text-foreground">
            {mode === "signin" ? "Welcome back" : "Create your account"}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Driver-first rideshare. Your ride, your price.
          </p>
        </div>

        <form onSubmit={submit} className="space-y-3">
          {mode === "signup" && (
            <>
              <input
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Full name"
                className="w-full bg-card rounded-xl px-4 py-3 text-sm border border-border outline-none focus:border-primary"
              />
              <div className="grid grid-cols-2 gap-2">
                {(["rider", "driver"] as const).map((t) => (
                  <button
                    type="button"
                    key={t}
                    onClick={() => setAccountType(t)}
                    className={`rounded-xl py-3 text-sm capitalize border transition ${
                      accountType === t
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-card text-muted-foreground border-border"
                    }`}
                  >
                    I'm a {t}
                  </button>
                ))}
              </div>
            </>
          )}
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            type="email"
            required
            placeholder="Email"
            className="w-full bg-card rounded-xl px-4 py-3 text-sm border border-border outline-none focus:border-primary"
          />
          <input
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            type="password"
            required
            minLength={6}
            placeholder="Password (min 6 chars)"
            className="w-full bg-card rounded-xl px-4 py-3 text-sm border border-border outline-none focus:border-primary"
          />

          {err && <div className="text-xs text-destructive">{err}</div>}

          <button
            disabled={busy}
            className="w-full bg-primary text-primary-foreground rounded-2xl py-3.5 font-medium disabled:opacity-60"
          >
            {busy ? "Please wait…" : mode === "signin" ? "Sign in" : "Create account"}
          </button>
        </form>

        <button
          onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
          className="mt-4 w-full text-sm text-muted-foreground"
        >
          {mode === "signin"
            ? "New to rollo? Create an account"
            : "Already have an account? Sign in"}
        </button>
      </div>
    </div>
  );
}