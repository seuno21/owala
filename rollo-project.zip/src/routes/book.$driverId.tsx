import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Phone, MessageSquare, Shield, Star } from "lucide-react";
import { RiderMap } from "@/components/rollo/RiderMap";
import { supabase } from "@/integrations/supabase/client";
import { useRequireAuth } from "@/lib/useAuth";

export const Route = createFileRoute("/book/$driverId")({
  head: () => ({ meta: [{ title: "rollo — your trip" }] }),
  component: BookPage,
});

type Phase = "confirm" | "matched" | "arriving" | "on_trip" | "complete";

const PHASE_TO_STATUS: Record<Exclude<Phase, "confirm">, string> = {
  matched: "matched",
  arriving: "arriving",
  on_trip: "on_trip",
  complete: "complete",
};

function BookPage() {
  const { user, loading } = useRequireAuth();
  const { driverId } = Route.useParams();
  const navigate = useNavigate();
  const [phase, setPhase] = useState<Phase>("confirm");
  const [bookingId, setBookingId] = useState<string | null>(null);

  const { data: driver } = useQuery({
    queryKey: ["driver", driverId],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("driver_profiles")
        .select("user_id, vehicle, base_fare, per_mile, per_min, eta_min, profiles!inner(full_name, rating)")
        .eq("user_id", driverId)
        .single();
      if (error) throw error;
      const miles = 5, mins = 12;
      const price = Number(data.base_fare) + Number(data.per_mile) * miles + Number(data.per_min) * mins;
      const p = data.profiles as unknown as { full_name: string; rating: number };
      return {
        id: data.user_id,
        name: p.full_name,
        rating: Number(p.rating),
        vehicle: data.vehicle,
        eta: data.eta_min,
        price: Math.round(price * 100) / 100,
        miles,
        mins,
      };
    },
  });

  const [eta, setEta] = useState(5);
  useEffect(() => { if (driver) setEta(driver.eta); }, [driver]);

  useEffect(() => {
    if (phase === "matched") {
      const t = setTimeout(() => setPhase("arriving"), 1500);
      return () => clearTimeout(t);
    }
    if (phase === "arriving") {
      const i = setInterval(() => setEta((e) => (e > 1 ? e - 1 : 1)), 1200);
      const t = setTimeout(() => setPhase("on_trip"), 5000);
      return () => { clearInterval(i); clearTimeout(t); };
    }
    if (phase === "on_trip") {
      const t = setTimeout(() => setPhase("complete"), 5000);
      return () => clearTimeout(t);
    }
  }, [phase]);

  // Persist booking status transitions
  useEffect(() => {
    if (!bookingId || phase === "confirm") return;
    supabase
      .from("bookings")
      .update({ status: PHASE_TO_STATUS[phase as Exclude<Phase, "confirm">] as never })
      .eq("id", bookingId)
      .then(() => {});
  }, [phase, bookingId]);

  async function confirmBooking() {
    if (!user || !driver) return;
    const savings = Math.round(driver.price * 0.28 * 100) / 100;
    const { data, error } = await supabase
      .from("bookings")
      .insert({
        rider_id: user.id,
        driver_id: driver.id,
        pickup: "Current location",
        dropoff: "Mission Bay",
        status: "matched",
        price: driver.price,
        miles: driver.miles,
        mins: driver.mins,
        savings_vs_uber: savings,
      })
      .select("id")
      .single();
    if (error) {
      console.error(error);
      return;
    }
    setBookingId(data.id);
    setPhase("matched");
  }

  if (loading || !user || !driver) {
    return <div className="min-h-screen bg-background" />;
  }

  return (
    <div className="min-h-screen bg-background flex justify-center">
      <div className="relative w-full max-w-[390px] min-h-screen bg-background overflow-hidden">
        <div className="absolute inset-0"><RiderMap /></div>

        <div className="relative z-10 flex items-center gap-2 px-4 pt-4">
          <button
            onClick={() => navigate({ to: "/" })}
            className="h-10 w-10 rounded-full bg-card shadow-sm flex items-center justify-center"
          >
            <ArrowLeft className="h-5 w-5 text-foreground" />
          </button>
          <div className="px-3 py-1.5 rounded-full bg-card shadow-sm">
            <span className="text-foreground text-sm font-medium">
              {phase === "confirm" && "Confirm your ride"}
              {phase === "matched" && "Matching…"}
              {phase === "arriving" && `Arriving in ${eta} min`}
              {phase === "on_trip" && "On the way"}
              {phase === "complete" && "Trip complete"}
            </span>
          </div>
        </div>

        <div className="absolute inset-x-0 bottom-0 z-10 bg-card rounded-t-3xl shadow-[0_-8px_24px_rgba(44,26,14,0.08)] pt-3 pb-6">
          <div className="mx-auto h-1 w-10 rounded-full bg-border mb-4" />

          {/* Driver row */}
          <div className="px-4 flex items-center gap-3">
            <div className="h-14 w-14 rounded-full bg-background flex items-center justify-center text-foreground font-medium">
              {driver.name.split(" ").map((p) => p[0]).join("")}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-foreground font-medium">{driver.name}</span>
                <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                  <Star className="h-3 w-3 fill-current text-foreground" />
                  {driver.rating.toFixed(1)}
                </span>
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">
                {driver.vehicle} · White Toyota Camry · 7XK B92
              </div>
            </div>
            <div className="flex gap-2">
              <button className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center">
                <MessageSquare className="h-4 w-4 text-foreground" />
              </button>
              <button className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center">
                <Phone className="h-4 w-4 text-foreground" />
              </button>
            </div>
          </div>

          {/* Trip info */}
          <div className="mx-4 mt-4 rounded-2xl border border-border p-3 space-y-2">
            <Row label="Pickup" value="Current location" dot="bg-primary" />
            <div className="h-px bg-border ml-[7px]" />
            <Row label="Dropoff" value="Mission Bay" dot="bg-success" />
          </div>

          <div className="mx-4 mt-3 flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Fare</span>
            <span className="text-foreground font-medium">${driver.price.toFixed(2)}</span>
          </div>
          <div className="mx-4 mt-1 flex items-center justify-between text-xs">
            <span className="text-success inline-flex items-center gap-1">
              <Shield className="h-3 w-3" /> Driver-set rate, no surge
            </span>
            <span className="text-success">Saved $4.20</span>
          </div>

          <div className="px-4 pt-4">
            {phase === "confirm" && (
              <button
                onClick={confirmBooking}
                className="w-full bg-primary text-primary-foreground rounded-2xl py-3.5 font-medium"
              >
                Confirm — ${driver.price.toFixed(2)}
              </button>
            )}
            {(phase === "matched" || phase === "arriving" || phase === "on_trip") && (
              <button
                onClick={() => navigate({ to: "/" })}
                className="w-full bg-secondary text-foreground rounded-2xl py-3.5 font-medium"
              >
                Cancel ride
              </button>
            )}
            {phase === "complete" && (
              <Link
                to="/rides"
                className="block text-center w-full bg-primary text-primary-foreground rounded-2xl py-3.5 font-medium"
              >
                Rate & tip {driver.name.split(" ")[0]}
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value, dot }: { label: string; value: string; dot: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className={`h-3 w-3 rounded-full ${dot}`} />
      <div className="flex-1">
        <div className="text-[11px] text-muted-foreground">{label}</div>
        <div className="text-sm text-foreground">{value}</div>
      </div>
    </div>
  );
}