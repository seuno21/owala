import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MapPin, Search } from "lucide-react";
import { RiderMap } from "@/components/rollo/RiderMap";
import { DriverCard } from "@/components/rollo/DriverCard";
import { FILTERS, type Filter, type Driver } from "@/components/rollo/data";
import { TabBar } from "@/components/rollo/TabBar";
import { supabase } from "@/integrations/supabase/client";
import { useRequireAuth } from "@/lib/useAuth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "rollo — your ride, your price" },
      {
        name: "description",
        content:
          "Rollo is a driver-first rideshare marketplace. See nearby drivers, their prices and ETAs, and pick the one you want.",
      },
      { property: "og:title", content: "rollo — your ride, your price" },
      {
        property: "og:description",
        content: "A live rideshare marketplace. Drivers set their rates. You choose.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  const { user, loading } = useRequireAuth();
  const [mode, setMode] = useState<"Ride" | "Fetch">("Ride");
  const [filter, setFilter] = useState<Filter>("All");
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const { data: drivers = [] } = useQuery({
    queryKey: ["drivers"],
    enabled: !!user,
    queryFn: async (): Promise<Driver[]> => {
      const { data, error } = await supabase
        .from("driver_profiles")
        .select("user_id, vehicle, tags, base_fare, per_mile, per_min, eta_min, is_online, profiles!inner(full_name, rating)")
        .eq("is_online", true);
      if (error) throw error;
      return (data ?? []).map((d) => {
        const miles = 5, mins = 12;
        const price = Number(d.base_fare) + Number(d.per_mile) * miles + Number(d.per_min) * mins;
        const p = d.profiles as unknown as { full_name: string; rating: number };
        return {
          id: d.user_id,
          name: p.full_name,
          vehicle: d.vehicle as Driver["vehicle"],
          tags: (d.tags ?? []) as Driver["tags"],
          price: Math.round(price * 100) / 100,
          eta: d.eta_min,
          rating: Number(p.rating),
        };
      });
    },
  });

  const filtered = useMemo(() => {
    if (filter === "All") return drivers;
    if (filter === "Sedan" || filter === "SUV / XL")
      return drivers.filter((d) => d.vehicle === filter);
    return drivers.filter((d) => (d.tags as string[]).includes(filter));
  }, [filter, drivers]);

  const selected =
    drivers.find((d) => d.id === selectedId) ?? filtered[0] ?? drivers[0] ?? null;

  if (loading || !user) {
    return <div className="min-h-screen bg-background" />;
  }

  return (
    <div className="h-screen bg-background flex justify-center overflow-hidden">
      <div className="relative w-full max-w-[390px] h-screen bg-background overflow-hidden">
        {/* Map — full-bleed background */}
        <div className="absolute inset-0 z-0">
          <RiderMap />
        </div>

        {/* Top bar */}
        <div className="absolute top-0 inset-x-0 z-20 flex items-center justify-between gap-2 px-4 pt-4">
          <div className="px-3 py-1.5 rounded-full bg-card shadow-sm">
            <span className="text-primary text-lg font-medium tracking-tight">rollo</span>
          </div>
          <button className="flex-1 ml-2 flex items-center gap-2 bg-card rounded-full px-4 py-2.5 shadow-sm text-left">
            <Search className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground truncate">Where to?</span>
          </button>
        </div>

        {/* Bottom sheet */}
        <div className="absolute inset-x-0 bottom-0 z-20">
          {/* Mode toggle */}
          <div className="px-4 pb-2 flex justify-center">
            <div className="inline-flex bg-card rounded-full p-1 shadow-sm border border-border">
              {(["Ride", "Fetch"] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => setMode(m)}
                  className={`px-5 py-1.5 text-sm rounded-full transition ${
                    mode === m
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground"
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-card rounded-t-3xl shadow-[0_-8px_24px_rgba(44,26,14,0.08)] pt-2 pb-4 max-h-[62vh] flex flex-col">
            <div className="mx-auto h-1 w-10 rounded-full bg-border mb-3" />

            {mode === "Fetch" ? (
              <FetchPanel />
            ) : (
              <>
                {/* Filters */}
                <div className="px-4 flex gap-2 overflow-x-auto no-scrollbar pb-2">
                  {FILTERS.map((f) => (
                    <button
                      key={f}
                      onClick={() => setFilter(f)}
                      className={`shrink-0 px-3 py-1.5 rounded-full text-xs border transition ${
                        filter === f
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-card text-muted-foreground border-border"
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                </div>

                {/* Savings bar */}
                <div className="mx-4 mt-1 mb-3 rounded-xl bg-success-soft text-success px-3 py-2 text-xs flex items-center gap-2">
                  <span className="font-medium">Avg 28% cheaper than Uber right now</span>
                </div>

                {/* Driver list */}
                <div className="px-4 flex-1 overflow-y-auto space-y-2">
                  {filtered.map((d) => (
                    <DriverCard
                      key={d.id}
                      driver={d}
                      selected={d.id === (selected?.id ?? null)}
                      onSelect={() => setSelectedId(d.id)}
                    />
                  ))}
                  {filtered.length === 0 && (
                    <div className="text-center text-sm text-muted-foreground py-8">
                      No drivers match this filter
                    </div>
                  )}
                </div>

                {/* Add stop + Book */}
                <div className="px-4 pt-3 space-y-2">
                  <button className="w-full text-sm text-muted-foreground py-2 rounded-xl border border-dashed border-border flex items-center justify-center gap-2">
                    <MapPin className="h-4 w-4" /> Add a stop
                  </button>
                  {selected ? (
                    <Link
                      to="/book/$driverId"
                      params={{ driverId: selected.id }}
                      className="block w-full text-center bg-primary text-primary-foreground rounded-2xl py-3.5 font-medium"
                    >
                      Book {selected.name.split(" ")[0]} — ${selected.price.toFixed(2)}
                    </Link>
                  ) : (
                    <div className="block w-full text-center bg-secondary text-muted-foreground rounded-2xl py-3.5">
                      Looking for drivers…
                    </div>
                  )}
                </div>
              </>
            )}
          </div>

          <TabBar />
        </div>
      </div>
    </div>
  );
}

function FetchPanel() {
  return (
    <div className="px-4 pb-2 space-y-3">
      <div>
        <label className="text-xs text-muted-foreground">What do you need?</label>
        <input
          placeholder="e.g. iced latte, oat milk"
          className="mt-1 w-full bg-background rounded-xl px-3 py-2.5 text-sm border border-border outline-none focus:border-primary"
        />
      </div>
      <div>
        <label className="text-xs text-muted-foreground">Pick up from</label>
        <input
          placeholder="Address or place name"
          className="mt-1 w-full bg-background rounded-xl px-3 py-2.5 text-sm border border-border outline-none focus:border-primary"
        />
      </div>
      <div>
        <label className="text-xs text-muted-foreground">Notes (optional)</label>
        <textarea
          rows={2}
          placeholder="Special instructions"
          className="mt-1 w-full bg-background rounded-xl px-3 py-2.5 text-sm border border-border outline-none focus:border-primary resize-none"
        />
      </div>
      <div className="rounded-xl bg-success-soft text-success px-3 py-2 text-xs">
        Estimated fetch fee: <span className="font-medium">$8.50</span>
      </div>
      <button className="w-full bg-primary text-primary-foreground rounded-2xl py-3.5 font-medium">
        See available drivers
      </button>
    </div>
  );
}
