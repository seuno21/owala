import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { CreditCard, Heart, Shield, Settings, HelpCircle, ChevronRight, LogOut } from "lucide-react";
import { PhoneFrame, TabBar } from "@/components/rollo/TabBar";
import { supabase } from "@/integrations/supabase/client";
import { useRequireAuth } from "@/lib/useAuth";

export const Route = createFileRoute("/profile")({
  head: () => ({ meta: [{ title: "rollo — your profile" }] }),
  component: ProfilePage,
});

function ProfilePage() {
  const { user, loading } = useRequireAuth();
  const navigate = useNavigate();

  const { data } = useQuery({
    queryKey: ["profile-page", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data: p } = await supabase
        .from("profiles")
        .select("full_name, avatar_initials, account_type, rating, created_at")
        .eq("id", user!.id)
        .maybeSingle();
      const { count } = await supabase
        .from("bookings")
        .select("id", { count: "exact", head: true })
        .eq("rider_id", user!.id);
      const { data: saved } = await supabase
        .from("bookings")
        .select("savings_vs_uber")
        .eq("rider_id", user!.id);
      const totalSaved = (saved ?? []).reduce((s, r) => s + Number(r.savings_vs_uber ?? 0), 0);
      return { profile: p, rideCount: count ?? 0, totalSaved };
    },
  });

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  }

  if (loading || !user) return <div className="min-h-screen bg-background" />;

  const p = data?.profile;
  const memberYear = p ? new Date(p.created_at).getFullYear() : new Date().getFullYear();
  const sections: { icon: typeof CreditCard; label: string; value?: string }[] = [
    { icon: CreditCard, label: "Payment", value: "Add card" },
    { icon: Heart, label: "Saved drivers", value: "0" },
    { icon: Shield, label: "Safety center" },
    { icon: Settings, label: "Preferences", value: p?.account_type },
    { icon: HelpCircle, label: "Help" },
  ];

  return (
    <PhoneFrame>
      <div className="flex-1 overflow-y-auto pb-4">
        <div className="px-4 pt-6 flex items-center gap-4">
          <div className="h-16 w-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xl font-medium">
            {p?.avatar_initials ?? "RO"}
          </div>
          <div>
            <div className="text-xl text-foreground">{p?.full_name ?? user.email}</div>
            <div className="text-sm text-muted-foreground">
              Member since {memberYear} · {p ? Number(p.rating).toFixed(2) : "5.00"} {p?.account_type ?? "rider"} rating
            </div>
          </div>
        </div>

        <div className="mx-4 mt-5 grid grid-cols-3 gap-2">
          <Stat label="Rides" value={String(data?.rideCount ?? 0)} />
          <Stat label="Saved" value={`$${(data?.totalSaved ?? 0).toFixed(0)}`} />
          <Stat label="Favorites" value="0" />
        </div>

        <div className="mx-4 mt-5 rounded-2xl border border-border bg-card overflow-hidden">
          {sections.map(({ icon: Icon, label, value }, i) => (
            <button
              key={label}
              className={`w-full flex items-center gap-3 px-4 py-3.5 text-left ${
                i !== sections.length - 1 ? "border-b border-border" : ""
              }`}
            >
              <Icon className="h-4 w-4 text-muted-foreground" />
              <span className="flex-1 text-sm text-foreground">{label}</span>
              {value && <span className="text-xs text-muted-foreground capitalize">{value}</span>}
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </button>
          ))}
        </div>

        <button
          onClick={signOut}
          className="mx-4 mt-5 w-[calc(100%-2rem)] flex items-center justify-center gap-2 rounded-2xl border border-border py-3 text-sm text-muted-foreground"
        >
          <LogOut className="h-4 w-4" /> Sign out
        </button>
      </div>
      <TabBar />
    </PhoneFrame>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-card border border-border px-3 py-3 text-center">
      <div className="text-lg text-foreground font-medium">{value}</div>
      <div className="text-[11px] text-muted-foreground mt-0.5">{label}</div>
    </div>
  );
}