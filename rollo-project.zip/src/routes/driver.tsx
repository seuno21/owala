import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { TrendingUp, Star, Clock, Car } from "lucide-react";
import { PhoneFrame, TabBar } from "@/components/rollo/TabBar";
import { supabase } from "@/integrations/supabase/client";
import { useRequireAuth } from "@/lib/useAuth";

export const Route = createFileRoute("/driver")({
  head: () => ({ meta: [{ title: "rollo — driver" }] }),
  component: DriverPage,
});

function DriverPage() {
  const { user, loading } = useRequireAuth();
  const qc = useQueryClient();
  const [online, setOnline] = useState(false);
  const [perMile, setPerMile] = useState(1.6);
  const [perMin, setPerMin] = useState(0.32);
  const [base, setBase] = useState(2.5);

  const { data: profile } = useQuery({
    queryKey: ["my-driver", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data: p } = await supabase
        .from("profiles")
        .select("full_name, account_type, rating")
        .eq("id", user!.id)
        .maybeSingle();
      const { data: dp } = await supabase
        .from("driver_profiles")
        .select("*")
        .eq("user_id", user!.id)
        .maybeSingle();
      return { profile: p, driver: dp };
    },
  });

  useEffect(() => {
    if (profile?.driver) {
      setOnline(profile.driver.is_online);
      setBase(Number(profile.driver.base_fare));
      setPerMile(Number(profile.driver.per_mile));
      setPerMin(Number(profile.driver.per_min));
    }
  }, [profile]);

  const isDriver = profile?.profile?.account_type === "driver";

  const { data: incoming = [] } = useQuery({
    queryKey: ["incoming-bookings", user?.id],
    enabled: !!user && isDriver,
    refetchInterval: 4000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bookings")
        .select("id, pickup, dropoff, miles, mins, price, status, profiles!bookings_rider_id_fkey(full_name)")
        .eq("driver_id", user!.id)
        .in("status", ["matched", "arriving", "on_trip"])
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  async function persist(patch: Partial<{ is_online: boolean; base_fare: number; per_mile: number; per_min: number }>) {
    if (!user || !isDriver) return;
    await supabase.from("driver_profiles").update(patch).eq("user_id", user.id);
    qc.invalidateQueries({ queryKey: ["my-driver"] });
    qc.invalidateQueries({ queryKey: ["drivers"] });
  }

  async function decide(id: string, accept: boolean) {
    await supabase
      .from("bookings")
      .update({ status: accept ? "arriving" : "cancelled" })
      .eq("id", id);
    qc.invalidateQueries({ queryKey: ["incoming-bookings"] });
  }

  if (loading || !user) return <div className="min-h-screen bg-background" />;

  return (
    <PhoneFrame>
      <div className="flex-1 overflow-y-auto pb-4">
        <div className="px-4 pt-6 flex items-center justify-between">
          <div>
            <div className="text-xs text-muted-foreground">Driver mode</div>
            <h1 className="text-2xl text-foreground">
              Good afternoon, {profile?.profile?.full_name?.split(" ")[0] ?? "there"}
            </h1>
          </div>
          <button
            onClick={() => { const v = !online; setOnline(v); persist({ is_online: v }); }}
            disabled={!isDriver}
            className={`px-4 py-2 rounded-full text-sm font-medium transition ${
              online ? "bg-success text-success-foreground" : "bg-secondary text-foreground"
            } disabled:opacity-50`}
          >
            {online ? "Online" : "Offline"}
          </button>
        </div>

        {!isDriver && (
          <div className="mx-4 mt-3 rounded-xl bg-secondary text-muted-foreground px-3 py-2 text-xs">
            Your account is set to rider. Driver controls are read-only.
          </div>
        )}

        <div className="mx-4 mt-4 grid grid-cols-3 gap-2">
          <Tile icon={<TrendingUp className="h-4 w-4" />} label="Active" value={String(incoming.length)} />
          <Tile icon={<Clock className="h-4 w-4" />} label="Status" value={online ? "Live" : "Off"} />
          <Tile icon={<Star className="h-4 w-4" />} label="Rating" value={profile?.profile?.rating ? Number(profile.profile.rating).toFixed(1) : "—"} />
        </div>

        <div className="mx-4 mt-5 rounded-2xl border border-border bg-card p-4">
          <div className="flex items-center gap-2">
            <Car className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-foreground">Your rate</span>
            <span className="ml-auto text-xs text-success">28% below local avg</span>
          </div>

          <Slider label="Per mile" prefix="$" value={perMile} min={0.8} max={3.5} step={0.05}
            onChange={(n) => { setPerMile(n); persist({ per_mile: n }); }} />
          <Slider label="Per minute" prefix="$" value={perMin} min={0.1} max={0.8} step={0.01}
            onChange={(n) => { setPerMin(n); persist({ per_min: n }); }} />
          <Slider label="Base fare" prefix="$" value={base} min={0} max={6} step={0.25}
            onChange={(n) => { setBase(n); persist({ base_fare: n }); }} />

          <div className="mt-3 rounded-xl bg-primary-soft px-3 py-2 text-xs text-foreground">
            Est. quote for 5 mi · 12 min ride:{" "}
            <span className="font-medium text-primary">
              ${(base + perMile * 5 + perMin * 12).toFixed(2)}
            </span>
          </div>
        </div>

        <div className="px-4 mt-5">
          <h2 className="text-sm font-medium text-foreground mb-2">Live requests</h2>
          {incoming.length === 0 && (
            <div className="rounded-2xl border border-dashed border-border p-5 text-center text-xs text-muted-foreground">
              {online ? "Waiting for a rider to pick you…" : "Go online to receive ride requests."}
            </div>
          )}
          <div className="space-y-2">
            {incoming.map((r) => {
              const rider = (r.profiles as unknown as { full_name: string } | null)?.full_name ?? "Rider";
              return (
                <div key={r.id} className="rounded-2xl border border-border bg-card p-4">
                  <div className="flex items-center justify-between">
                    <span className="text-foreground font-medium">{rider}</span>
                    <span className="text-foreground font-medium">${Number(r.price).toFixed(2)}</span>
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {r.pickup} → {r.dropoff} · {Number(r.miles)} mi · {r.mins} min · {r.status}
                  </div>
                  <div className="mt-3 flex gap-2">
                    <button onClick={() => decide(r.id, false)} className="flex-1 bg-secondary text-foreground rounded-xl py-2 text-sm">
                      Decline
                    </button>
                    <button onClick={() => decide(r.id, true)} className="flex-1 bg-primary text-primary-foreground rounded-xl py-2 text-sm font-medium">
                      Accept
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      <TabBar />
    </PhoneFrame>
  );
}

function Tile({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-card border border-border px-3 py-3">
      <div className="text-muted-foreground">{icon}</div>
      <div className="text-lg text-foreground font-medium mt-1">{value}</div>
      <div className="text-[11px] text-muted-foreground">{label}</div>
    </div>
  );
}

function Slider({
  label, prefix, value, min, max, step, onChange,
}: {
  label: string; prefix: string; value: number; min: number; max: number; step: number;
  onChange: (n: number) => void;
}) {
  return (
    <div className="mt-3">
      <div className="flex justify-between text-xs">
        <span className="text-muted-foreground">{label}</span>
        <span className="text-foreground font-medium">{prefix}{value.toFixed(2)}</span>
      </div>
      <input
        type="range"
        min={min} max={max} step={step} value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full mt-1 accent-primary"
      />
    </div>
  );
}