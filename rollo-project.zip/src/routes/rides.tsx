import { createFileRoute } from "@tanstack/react-router";
import { Star } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { PhoneFrame, TabBar } from "@/components/rollo/TabBar";
import { supabase } from "@/integrations/supabase/client";
import { useRequireAuth } from "@/lib/useAuth";

export const Route = createFileRoute("/rides")({
  head: () => ({ meta: [{ title: "rollo — your rides" }] }),
  component: RidesPage,
});

function RidesPage() {
  const { user, loading } = useRequireAuth();

  const { data: rides = [] } = useQuery({
    queryKey: ["my-bookings", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bookings")
        .select("id, pickup, dropoff, price, savings_vs_uber, rating, created_at, status, driver_id, profiles!bookings_driver_id_fkey(full_name)")
        .eq("rider_id", user!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const totalSaved = rides.reduce((s, r) => s + Number(r.savings_vs_uber ?? 0), 0);

  if (loading || !user) return <div className="min-h-screen bg-background" />;

  return (
    <PhoneFrame>
      <div className="flex-1 overflow-y-auto pb-4">
        <div className="px-4 pt-6">
          <h1 className="text-2xl text-foreground">Your rides</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Every trip you booked through rollo.
          </p>
        </div>

        <div className="mx-4 mt-4 rounded-2xl bg-success-soft text-success px-4 py-3">
          <div className="text-xs">Total saved vs Uber</div>
          <div className="text-2xl font-medium">${totalSaved.toFixed(2)}</div>
        </div>

        <div className="px-4 mt-4 space-y-2">
          {rides.length === 0 && (
            <div className="rounded-2xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
              No rides yet. Book your first one from Home.
            </div>
          )}
          {rides.map((r) => {
            const drv = r.profiles as unknown as { full_name: string } | null;
            const date = new Date(r.created_at).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
            const stars = r.rating ?? 0;
            return (
              <div key={r.id} className="rounded-2xl border border-border bg-card p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-xs text-muted-foreground">{date} · {r.status}</div>
                    <div className="mt-1 text-foreground font-medium">
                      {r.pickup} → {r.dropoff}
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground">
                      {drv?.full_name ?? "Driver"}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-foreground font-medium">${Number(r.price).toFixed(2)}</div>
                    <div className="text-[11px] text-success mt-0.5">saved ${Number(r.savings_vs_uber).toFixed(2)}</div>
                  </div>
                </div>
                <div className="mt-3 flex items-center gap-1">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`h-3.5 w-3.5 ${i < stars ? "fill-current text-foreground" : "text-border"}`}
                    />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      <TabBar />
    </PhoneFrame>
  );
}