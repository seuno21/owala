import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

const pinIcon = (color: string) =>
  L.divIcon({
    className: "rollo-pin",
    html: `<div style="width:22px;height:22px;border-radius:9999px;background:${color};border:3px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.25)"></div>`,
    iconSize: [22, 22],
    iconAnchor: [11, 11],
  });

export function RiderMap() {
  const rider: [number, number] = [37.7749, -122.4194];
  const dest: [number, number] = [37.7849, -122.4094];
  return (
    <MapContainer
      center={rider}
      zoom={14}
      zoomControl={false}
      attributionControl={false}
      style={{ position: "absolute", inset: 0, height: "100%", width: "100%" }}
    >
      <TileLayer url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png" />
      <Marker position={rider} icon={pinIcon("#C4622D")}>
        <Popup>You are here</Popup>
      </Marker>
      <Marker position={dest} icon={pinIcon("#2D6A4F")}>
        <Popup>Destination</Popup>
      </Marker>
    </MapContainer>
  );
}