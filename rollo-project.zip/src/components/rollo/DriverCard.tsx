import { Star } from "lucide-react";
import type { Driver } from "./data";

function initials(name: string) {
  return name
    .split(" ")
    .map((p) => p[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

export function DriverCard({
  driver,
  selected,
  onSelect,
}: {
  driver: Driver;
  selected: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      onClick={onSelect}
      className={`w-full text-left rounded-2xl bg-card p-4 flex items-center gap-3 transition border ${
        selected ? "border-primary shadow-sm" : "border-border"
      }`}
    >
      <div className="h-12 w-12 rounded-full bg-background flex items-center justify-center text-foreground font-medium shrink-0">
        {initials(driver.name)}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-foreground font-medium">{driver.name}</span>
          <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
            <Star className="h-3 w-3 fill-current text-foreground" />
            {driver.rating.toFixed(1)}
          </span>
        </div>
        <div className="mt-1 flex flex-wrap gap-1.5">
          <span className="text-[11px] px-2 py-0.5 rounded-full bg-primary-soft text-foreground">
            {driver.vehicle}
          </span>
          {driver.tags.map((t) => (
            <span
              key={t}
              className={`text-[11px] px-2 py-0.5 rounded-full ${
                t === "Top rated"
                  ? "bg-success-soft text-success"
                  : "bg-secondary text-muted-foreground"
              }`}
            >
              {t}
            </span>
          ))}
        </div>
      </div>
      <div className="text-right shrink-0">
        <div className="text-lg font-medium text-foreground">${driver.price.toFixed(2)}</div>
        <div className="text-xs text-muted-foreground">{driver.eta} min</div>
      </div>
    </button>
  );
}