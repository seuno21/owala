import { Link } from "@tanstack/react-router";
import { MapPin, Clock, User, Car } from "lucide-react";

const items = [
  { to: "/", label: "Home", icon: MapPin },
  { to: "/rides", label: "Rides", icon: Clock },
  { to: "/driver", label: "Drive", icon: Car },
  { to: "/profile", label: "Profile", icon: User },
] as const;

export function TabBar() {
  return (
    <div className="bg-card border-t border-border flex justify-around py-2">
      {items.map(({ to, label, icon: Icon }) => (
        <Link
          key={to}
          to={to}
          className="flex flex-col items-center gap-0.5 text-[11px] text-muted-foreground"
          activeProps={{ className: "flex flex-col items-center gap-0.5 text-[11px] text-primary" }}
          activeOptions={{ exact: true }}
        >
          <Icon className="h-5 w-5" />
          {label}
        </Link>
      ))}
    </div>
  );
}

export function PhoneFrame({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-background flex justify-center">
      <div className="relative w-full max-w-[390px] min-h-screen bg-background overflow-hidden flex flex-col">
        {children}
      </div>
    </div>
  );
}