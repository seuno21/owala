export type Driver = {
  id: string;
  name: string;
  vehicle: "Sedan" | "SUV / XL" | "XL Van" | "Luxury";
  tags: ("Female driver" | "Pet-friendly" | "Top rated")[];
  price: number;
  eta: number;
  rating: number;
};

export const drivers: Driver[] = [
  { id: "1", name: "Maya R.", vehicle: "Sedan", tags: ["Top rated", "Female driver"], price: 12.4, eta: 3, rating: 4.9 },
  { id: "2", name: "Jamal T.", vehicle: "SUV / XL", tags: ["Pet-friendly"], price: 16.8, eta: 5, rating: 4.8 },
  { id: "3", name: "Sofia L.", vehicle: "Sedan", tags: ["Female driver"], price: 11.95, eta: 6, rating: 4.7 },
  { id: "4", name: "Derek M.", vehicle: "SUV / XL", tags: ["Top rated"], price: 17.5, eta: 4, rating: 4.95 },
  { id: "5", name: "Aisha K.", vehicle: "Sedan", tags: ["Pet-friendly", "Female driver"], price: 13.2, eta: 8, rating: 4.6 },
  { id: "6", name: "Luis P.", vehicle: "XL Van", tags: [], price: 21.0, eta: 9, rating: 4.5 },
];

export const FILTERS = ["All", "Sedan", "SUV / XL", "Female driver", "Pet-friendly"] as const;
export type Filter = (typeof FILTERS)[number];

export type PastRide = {
  id: string;
  date: string;
  driver: string;
  vehicle: string;
  from: string;
  to: string;
  price: number;
  rating: number;
  saved: number;
};

export const pastRides: PastRide[] = [
  { id: "r1", date: "Today · 2:14 PM", driver: "Maya R.", vehicle: "Sedan", from: "Home", to: "Mission Bay", price: 12.4, rating: 5, saved: 4.6 },
  { id: "r2", date: "Yesterday · 9:02 AM", driver: "Derek M.", vehicle: "SUV / XL", from: "Home", to: "SFO Terminal 2", price: 32.8, rating: 5, saved: 11.2 },
  { id: "r3", date: "Fri · 7:48 PM", driver: "Sofia L.", vehicle: "Sedan", from: "The Mill", to: "Hayes Valley", price: 9.5, rating: 4, saved: 3.1 },
  { id: "r4", date: "Thu · 11:30 AM", driver: "Aisha K.", vehicle: "Sedan", from: "Home", to: "Vet — Pet-friendly", price: 14.2, rating: 5, saved: 5.4 },
];